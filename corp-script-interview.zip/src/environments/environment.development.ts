import { IEnvironments } from './environments.interface';

export const environment: IEnvironments = {
  apiVersion: '',
  production: true,
  baseUrl: 'http://corpscript.ddns.net:3000/api/',
};
