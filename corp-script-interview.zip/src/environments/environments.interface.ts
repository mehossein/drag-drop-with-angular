export interface IEnvironments {
  apiVersion: string;
  production: boolean;
  baseUrl: string;
}
