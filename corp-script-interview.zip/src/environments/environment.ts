import { IEnvironments } from './environments.interface';

export const environment: IEnvironments = {
  apiVersion: '',
  production: false,
  baseUrl: 'http://corpscript.ddns.net:3000/api/',
};
