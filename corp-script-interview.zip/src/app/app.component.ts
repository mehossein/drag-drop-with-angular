import { Component } from '@angular/core';

@Component({
  selector: 'corp-root',
  template: `<corp-parent></corp-parent>`,
})
export class AppComponent {}
