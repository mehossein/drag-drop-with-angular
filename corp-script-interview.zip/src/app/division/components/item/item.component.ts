import { Component } from '@angular/core';

@Component({
  selector: 'corp-item',
  templateUrl: './item.component.html',
  styleUrls: ['./item.component.scss']
})
export class ItemComponent {

}
