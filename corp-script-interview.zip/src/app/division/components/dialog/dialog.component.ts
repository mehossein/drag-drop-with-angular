import { Component } from '@angular/core';

@Component({
  selector: 'corp-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.scss']
})
export class DialogComponent {

}
