import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'corp-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss'],
})
export class ListComponent {
  constructor() {}
}
